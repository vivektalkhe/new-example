package com.cg.appl.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.hibernate.TransactionException;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;

@Repository("traineeDao")
public class TraineeDaoImpl implements TraineeDao {

	private EntityManagerFactory factory;
	public TraineeDaoImpl() {
		
	}

	@Resource(name="entityManagerFactory")
	public void setEntityManagerFactory(EntityManagerFactory factory)
	{
		this.factory=factory;
	}
	@Override
	public Trainee getTraineeDetails(int traineeId) throws TraineeExceptions {
		Trainee trainee;
		try {
			EntityManager manager =factory.createEntityManager();
			trainee = manager.find(Trainee.class, traineeId);
			if(trainee!=null)
			{
				System.out.println("Your record is found");
				return trainee;
			}
			else
			{
				System.out.println("Your record is not found");
				throw new TraineeExceptions("Your record is not found");
			}
		} catch (Exception e) {
			throw new TraineeExceptions("retrieval failed",e);
		}
	}

	@Override
	public List<Trainee> showAllDetails() throws TraineeExceptions {
		String qryStr="select t from trainee t";
		EntityManager manager=factory.createEntityManager();
		Query qry=manager.createQuery(qryStr, Trainee.class);
		
		return qry.getResultList();
	}

	@Override
	public Trainee insertNewTrainee(Trainee trainee) throws TraineeExceptions,RollbackException {
		EntityManager manager=factory.createEntityManager();
		try {
			System.out.println(trainee);
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			manager.persist(trainee);
			trans.commit();
		} catch (RollbackException e) {

			throw new TransactionException("Record Not Committed",e);
		}
		return trainee;
	}

}
