package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Trainee;
import com.cg.appl.exceptions.TraineeExceptions;
import com.cg.appl.services.TraineeServices;

@Controller
public class TraineeCRUD {
	private TraineeServices services;
	private List<String> domainList;
	private List<String> locations;
	private List<String> genderList;
	private List<String> skillList; 
	
	@PostConstruct
	public void initialize(){
		domainList=new ArrayList<>();
		domainList.add("Java");
		domainList.add("DotNet");
		domainList.add("Database");
		domainList.add("Analytics");
			
		locations=new ArrayList<>();
		locations.add("Pune");
		locations.add("Mumbai");
		locations.add("Bangluru");
		locations.add("Kolkatta");
		locations.add("Delhi");
		
		genderList=new ArrayList<>();
		genderList.add("Male");
		genderList.add("Female");
		genderList.add("Others");
		
		skillList=new ArrayList();
		skillList.add("ProblemSolving");
		skillList.add("PublicSpeaking");
		skillList.add("TimeManagement");
		skillList.add("VerbalCommunication");
	}

	@Resource(name = "traineeService")
	public void setServices(TraineeServices services) {
		this.services = services;
	}

	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}

	
	@RequestMapping("/traineeDetails.do")//entertraineeno
	public ModelAndView dispatchForm() {
		ModelAndView model = new ModelAndView("empDetails");//entertraineeno
		return model;
	}

	
	@RequestMapping("/getDetails.do")//gettraineedetails
	public ModelAndView getDetails(@RequestParam("id") String getId)
			throws TraineeExceptions {
		System.out.println(getId);
		Trainee trainee;
		ModelAndView model = new ModelAndView();
		try {
			trainee = services.getTraineeDetails(Integer.parseInt(getId));
			model.setViewName("success");
			model.addObject("Id", getId);
			model.addObject("traineeDetail", trainee);

		} catch (NumberFormatException | TraineeExceptions e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());

		}

		return model;

	}

	@RequestMapping("/showAlldetails.do")
	public ModelAndView showAllList() throws TraineeExceptions {

		ModelAndView model = new ModelAndView();
		try {
			List<Trainee> traineeList = services.showAllDetails();
			model.setViewName("traineeList");
			model.addObject("trainee",traineeList);
		} catch (TraineeExceptions e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm");
		
		model.addObject("trainee", new Trainee());
		model.addObject("domains", domainList);
		model.addObject("locations", locations);
		model.addObject("gender",genderList);
		model.addObject("skill",skillList);

		
		return model;//go to jsp
	}
	
	@RequestMapping("/submitEntryForm.do")
	public ModelAndView submitEntryForm(@ModelAttribute @Valid Trainee trainee,BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors())
		{
			model.setViewName("entryForm");
			//model.addObject("trainee", new Trainee());
			model.addObject("domains", domainList);
			model.addObject("locations", locations);
			model.addObject("gender",genderList);
			model.addObject("skill",skillList);
			return model;
		
		}
		try {
			Trainee traineeResponse=services.insertNewTrainee(trainee);

			model = new ModelAndView("succesInsert");
			model.addObject("trainee", traineeResponse);
		} catch (TraineeExceptions e) {
			model = new ModelAndView("error");
			model.addObject("exceptions", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	
	@RequestMapping("/updateTrainee.do")//gettraineedetails
	public ModelAndView updateTrainee(@RequestParam("id") String getId)
			throws TraineeExceptions {
		System.out.println(getId);
		Trainee trainee;
		ModelAndView model = new ModelAndView();
		model.setViewName("error");
		model.addObject("exceptions","Dummy Message");
		/*try {
			trainee = services.getTraineeDetails(Integer.parseInt(getId));
			model.setViewName("success");
			model.addObject("Id", getId);
			model.addObject("traineeDetail", trainee);

		} catch (NumberFormatException | TraineeExceptions e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());

		}
*/
		return model;

	}
}