package com.cg.appl.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;


import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;
import com.cg.appl.services.EmpServices;



@Controller
public class EmpCRUD {
	private EmpServices services;
	
	
	
	@PostConstruct
	public void initialize(){
		
	}

	@Resource(name = "empService")
	public void setServices(EmpServices services) {
		this.services = services;
	}

	@RequestMapping("/welcome.do")
	public ModelAndView getWelcomePage() {
		ModelAndView model = new ModelAndView("welcome");
		return model;
	}

	
	@RequestMapping("/enterEmpNo.do")//entertraineeno
	public ModelAndView enterEmpNo() {
		ModelAndView model = new ModelAndView("enterEmpNo");//entertraineeno
		return model;
	}

	
	@RequestMapping("/getEmpDetails.do")//gettraineedetails
	public ModelAndView getEmpDetails(@RequestParam("empNo") String empNo)
			throws EmpException {
		System.out.println(empNo);
		Emp emp;
		ModelAndView model = new ModelAndView();
		try {
			emp = services.getEmpDetails(Integer.parseInt(empNo));
			model.setViewName("empDetailsuccess");
			//model.addObject("Id", empNo);
			model.addObject("empDetails", emp);

		} catch (NumberFormatException | EmpException e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());

		}

		return model;

	}

	@RequestMapping("/listAllEmps.do")
	public ModelAndView listAllEmps() throws EmpException {

		ModelAndView model = new ModelAndView();
		try {
			List<Emp> emps = services.showAllDetails();
			model.setViewName("listAllEmps");
			model.addObject("emps",emps);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());
		}
		return model;
	}
	
	@RequestMapping("/getUpdateForm.do")
	public ModelAndView getUpdateForm(@RequestParam("id") int enpNo) {
		
		ModelAndView model=null;
		try {
			Emp emp=services.getEmpDetails(enpNo);
			model = new ModelAndView("updateForm");
			
			model.addObject("emp",emp);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());
		}
		
		return model;//go to jsp
	}
	
	
	
	@RequestMapping("/submitUpdateForm.do")
	public ModelAndView submitUpdateForm(@ModelAttribute("emp") @Valid Emp emp,BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors())
		{
			System.out.println(result.getAllErrors());
			model.setViewName("updateForm");
			//model.addObject("trainee", new Trainee());
			model.addObject("emp", emp);
			return model;
		}
		try {
			Emp empResponse=services.updateEmp(emp);
			model = new ModelAndView("successUpdate");
			model.addObject("empDetails", empResponse);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("exceptions", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
	
	
	@RequestMapping("/DeleteForm.do")
	public ModelAndView getDeleteForm(@RequestParam("id") int enpNo) {
		
		ModelAndView model=null;
		try {
			boolean emp=services.deleteEmp(enpNo);
			model = new ModelAndView("deleteSuccess");
			model.addObject("enp",enpNo);
		} catch (EmpException e) {
			model.setViewName("error");
			model.addObject("exceptions", e.getMessage());
		}
		
		return model;//go to jsp
	}
	
	
	
	
	@RequestMapping("/entryForm.do")
	public ModelAndView getEntryForm() {
		ModelAndView model = new ModelAndView("entryForm");
		model.addObject("emp", new Emp());
		return model;//go to jsp
	}
	
	@RequestMapping("/succesInsert.do")
	public ModelAndView submitEntryForm(@ModelAttribute("emp") @Valid Emp emp,BindingResult result) {
		ModelAndView model = new ModelAndView();
		if(result.hasErrors())
		{
			model.setViewName("entryForm");
			//model.addObject("trainee", new Trainee());
			return model;
		
		}
		try {
			Emp empResponse=services.insertNewEmp(emp);

			model = new ModelAndView("succesInsert");
			model.addObject("emp", empResponse);
		} catch (EmpException e) {
			model = new ModelAndView("error");
			model.addObject("exceptions", "Record Insertion Failed:"+e.getMessage());
		}
		return model;
	}
	
}