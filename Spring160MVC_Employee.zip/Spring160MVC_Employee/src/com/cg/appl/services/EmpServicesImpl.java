package com.cg.appl.services;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.persistence.RollbackException;
import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.appl.dao.EmpDao;
import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;

@Service("empService")
public class EmpServicesImpl implements EmpServices {

	private EmpDao dao;

	@Resource(name = "empDao")
	public void setDao(EmpDao dao) {
		this.dao = dao;
	}
/*
	@Override
	public Trainee get EmpDetails(int empId) throws EmpException {
		 Emp emp = null;
		try {
			emp = dao.get EmpDetails(traineeId);
			return emp;
		} catch ( EmpException e) {

			throw new  EmpException("Your record is not found", e);

		}

	}

	@Override
	public List<Trainee> showAllDetails() throws TraineeExceptions {
		
		try {
			List<Trainee> traineeList= dao.showAllDetails();
			return traineeList;
		} catch (TraineeExceptions e) {
			
			throw new TraineeExceptions("Your List is not retrieved",e);
		}
	}*/
	
	
	
	
	@Transactional
	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.insertNewEmp(emp);
	}

	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		// TODO Auto-generated method stub
		return dao.getEmpDetails(empId);
	}

	public List<Emp> showAllDetails() throws EmpException {
		
		return dao.showAllDetails();
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException {
		// TODO Auto-generated method stub
		return dao.updateEmp(emp);
	}




	@Override
	public boolean deleteEmp(int empId) throws EmpException{
		// TODO Auto-generated method stub
		return dao.deleteEmp(empId);
	}

}
