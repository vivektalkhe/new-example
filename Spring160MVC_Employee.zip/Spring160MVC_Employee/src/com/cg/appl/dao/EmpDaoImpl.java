package com.cg.appl.dao;

import java.util.List;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Query;
import javax.persistence.RollbackException;

import org.hibernate.TransactionException;
import org.springframework.stereotype.Repository;

import com.cg.appl.entities.Emp;
import com.cg.appl.exceptions.EmpException;



@Repository("empDao")
public class EmpDaoImpl implements EmpDao {

	private EntityManagerFactory factory;
	public EmpDaoImpl() {
		
	}

	@Resource(name="entityManagerFactory")
	public void setEntityManagerFactory(EntityManagerFactory factory)
	{
		this.factory=factory;
	}


	@Override
	public List<Emp> showAllDetails() throws EmpException {
		EntityManager manager=factory.createEntityManager();
		Query qry=manager.createNamedQuery("qryAllEmps",Emp.class);
		
		return qry.getResultList();
	}


	@Override
	public Emp getEmpDetails(int empId) throws EmpException {
		
		Emp emp;
		
		try {
			EntityManager manager =factory.createEntityManager();
			emp = manager.find(Emp.class, empId);
			if(emp!=null)
			{
				System.out.println("Your record is found");
				return emp;
			}
			else
			{
				System.out.println("Your record is not found");
				throw new EmpException("Your record is not found");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Retrival Failed");
		}
	}

	@Override
	public Emp insertNewEmp(Emp emp) throws EmpException, RollbackException {
		
		EntityManager manager=factory.createEntityManager();
		
		try {
			System.out.println(emp);
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			manager.persist(emp);
			trans.commit();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			throw new EmpException("Record not committed");
		}
		return emp;
	}

	@Override
	public Emp updateEmp(Emp emp) throws EmpException,RollbackException {

		EntityManager manager=factory.createEntityManager();
		try {
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			manager.merge(emp);
			trans.commit();
		} catch (Exception e) {
			throw new EmpException("Record not Updated");

		}
		return emp;
	}

	@Override
	public boolean deleteEmp(int empId) throws EmpException,RollbackException {
			EntityManager manager=factory.createEntityManager();
			Emp emp;

		try {
			EntityTransaction trans=manager.getTransaction();
			trans.begin();
			emp=manager.find(Emp.class,empId);
			manager.remove(emp);
			System.out.println("*************Delete Query From Merge");
			trans.commit();
			return true;
		} catch (Exception e) {
			throw new EmpException("Failed Name Deletion",e);
		}
	}

}
